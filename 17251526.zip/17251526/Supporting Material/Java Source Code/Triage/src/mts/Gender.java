package mts;

enum Gender {
	Male, Female;
}
