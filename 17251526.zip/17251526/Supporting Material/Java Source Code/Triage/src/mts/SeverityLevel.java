package mts;

enum SeverityLevel {
	Immediate, VeryUrgent, Urgent, Standard, NonUrgent;
}
