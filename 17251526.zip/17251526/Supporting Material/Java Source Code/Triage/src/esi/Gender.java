package esi;

enum Gender {
	Male, Female;
}
