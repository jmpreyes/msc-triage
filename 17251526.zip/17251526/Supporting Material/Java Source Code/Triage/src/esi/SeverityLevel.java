package esi;

enum SeverityLevel {
	Immediate, VeryUrgent, Urgent, Minor, Delayed;
}
